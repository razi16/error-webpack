/* eslint-disable no-console */
import 'regenerator-runtime';

console.log('Hello Coders!');
